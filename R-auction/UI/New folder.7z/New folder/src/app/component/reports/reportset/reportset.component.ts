import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reportset',
  templateUrl: './reportset.component.html',
  styleUrls: ['./reportset.component.css']
})
export class ReportsetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
