import { PreitemPipe } from './preitem.pipe';

describe('PreitemPipe', () => {
  it('create an instance', () => {
    const pipe = new PreitemPipe();
    expect(pipe).toBeTruthy();
  });
});
