export const environment = {
  flag:"replica",
  production: true,
  rauction:"/rauction/",
  baseUrlCore: "/pnc/",
  baseUrlAuction: "/pnc/",
  baseUrlMachineLearning: "/pnc/",
  userProfile: "/pnc/",
  commonUrlDocument: "/commons/",
  applicationUrl: "https://azmobilityqas.ril.com:8443/rauction/",
  loginUrl: "https://azmobilityqas.ril.com:8443/pnc/auth/login",
  // baseUrlCommon:"http://10.26.32.154:8032/",
  baseUrlBid: "/pnc/",
  baseUrlMaterial: "/pnc/",
  socketURL: { auction: "https://azmobilityqas.ril.com:8443", auctionURL: "/pnc/auction/scheduler", bid: "https://azmobilityqas.ril.com:8443", bidURL: "/pnc/auction/bid", query: "https://azmobilityqas.ril.com:8443", queryURL: "/pnc/auction/query"}
};
